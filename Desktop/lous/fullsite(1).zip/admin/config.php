<?php
// HTTP
define('HTTP_SERVER', 'http://nvinfobase.com/demo/development/LouisLi/admin/');
define('HTTP_CATALOG', 'http://nvinfobase.com/demo/development/LouisLi/');

// HTTPS
define('HTTPS_SERVER', 'http://nvinfobase.com/demo/development/LouisLi/admin/');
define('HTTPS_CATALOG', 'http://nvinfobase.com/demo/development/LouisLi/');

// DIR
define('DIR_APPLICATION', '/home/nvnfb7as/public_html/demo/development/LouisLi/admin/');
define('DIR_SYSTEM', '/home/nvnfb7as/public_html/demo/development/LouisLi/system/');
define('DIR_LANGUAGE', '/home/nvnfb7as/public_html/demo/development/LouisLi/admin/language/');
define('DIR_TEMPLATE', '/home/nvnfb7as/public_html/demo/development/LouisLi/admin/view/template/');
define('DIR_CONFIG', '/home/nvnfb7as/public_html/demo/development/LouisLi/system/config/');
define('DIR_IMAGE', '/home/nvnfb7as/public_html/demo/development/LouisLi/image/');
define('DIR_CACHE', '/home/nvnfb7as/public_html/demo/development/LouisLi/system/cache/');
define('DIR_DOWNLOAD', '/home/nvnfb7as/public_html/demo/development/LouisLi/system/download/');
define('DIR_UPLOAD', '/home/nvnfb7as/public_html/demo/development/LouisLi/system/upload/');
define('DIR_LOGS', '/home/nvnfb7as/public_html/demo/development/LouisLi/system/logs/');
define('DIR_MODIFICATION', '/home/nvnfb7as/public_html/demo/development/LouisLi/system/modification/');
define('DIR_CATALOG', '/home/nvnfb7as/public_html/demo/development/LouisLi/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'nvnfb7as_webastr');
define('DB_PASSWORD', 'admin123!@#');
define('DB_DATABASE', 'nvnfb7as_LouisLi');
define('DB_PREFIX', 'oc_');
