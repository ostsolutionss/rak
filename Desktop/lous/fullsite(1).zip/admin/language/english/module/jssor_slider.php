<?php
/*
@idiotique
*/
// Heading
$_['heading_title']    = 'Jssor Slideshow';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified slideshow module!';
$_['text_edit']        = 'Edit Slideshow Module';

// Entry
$_['entry_banner']     = 'Banner';
$_['entry_dimension']  = 'Dimension';
$_['entry_width']      = 'Width';
$_['entry_height']     = 'Height';
$_['entry_status']     = 'Status';
//$_['entry_image']      = 'Image';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify slideshow module!';
$_['error_dimension']  = 'Width &amp; Height dimensions required!';

// Tab
$_['tab_slideshow'] 	= 'Slideshow Module';
//$_['tab_caption'] 	  = 'Translation Caption';
//$_['tab_translation']= 'Translation Slide';
$_['help_dimension']   = '(W x H) and Resize Type';
