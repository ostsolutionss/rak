<?php
// Heading
$_['heading_title']     = '最新订单';

// Column
$_['column_order_id']   = '订单号';
$_['column_customer']   = '客户名称';
$_['column_status']     = '状态';
$_['column_total']      = '金额';
$_['column_date_added'] = '生成日期';
$_['column_action']     = '管理';