<?php
$_['lang_openbay_new']              = '创建新列表';
$_['lang_openbay_edit']             = '检视/编辑列表';
$_['lang_openbay_fix']              = '修正错误';
$_['lang_openbay_processing']       = '处理中';

$_['lang_amazonus_saved']           = '保存(尚没上传)'; 
$_['lang_amazon_saved']             = '保存(尚没上传)';

$_['lang_markets']                  = '市场'; 
$_['lang_bulk_btn']                 = 'eBay 批量上传'; 
$_['lang_bulk_amazon_btn']          = 'Amazon EU 批量上传';

$_['lang_marketplace']              = '市場(Marketplace)'; 
$_['lang_status']                   = '状态'; 
$_['lang_option']                   = '选项';
?>