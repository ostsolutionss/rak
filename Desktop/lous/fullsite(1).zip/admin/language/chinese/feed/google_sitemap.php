<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = '插件扩展';
$_['text_success']     = '成功： 您已变更Google Sitemap资料！';
$_['text_edit']        = '编辑Google Sitemap';

// Entry
$_['entry_status']     = '状态：';
$_['entry_data_feed']  = '资料数据网址：';

// Error
$_['error_permission'] = '警告： 您没有权限修改Google Sitemap相关资料！';
