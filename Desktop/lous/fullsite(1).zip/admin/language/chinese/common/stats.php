<?php
$_['text_complete_status']   = '订单完成'; 
$_['text_processing_status'] = '订单处理中'; 
$_['text_other_status']      = '其他状态'; 