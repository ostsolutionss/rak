<?php

// Heading
$_['heading_title']  = '商品浏览报表';

// Text
$_['text_success']   = '成功： 您已重设商品浏览报表！';

// Column
$_['column_name']    = '商品名称';
$_['column_model']   = '商品型号';
$_['column_viewed']  = '浏览次数';
$_['column_percent'] = '按百分比';
?>
