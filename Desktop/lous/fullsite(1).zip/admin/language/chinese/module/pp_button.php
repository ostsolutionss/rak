<?php
// Heading
$_['heading_title']    = 'PayPal快速结帐按钮';

// Text
$_['text_module']      = '模块';
$_['text_success']     = '成功：您已修改PayPal快速结帐按钮！';
$_['text_edit']        = '编辑PayPal快速结帐按钮';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告：您没有权限修改PayPal快速结帐按钮模块！';