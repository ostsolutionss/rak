<?php
$_['heading_title'] = 'OpenBay Pro';

$_['text_module'] = '模块';
$_['text_installed'] = 'OpenBay专业模块现已安装完毕。 您可在 Extensions -> OpenBay Pro 下找到';
?>