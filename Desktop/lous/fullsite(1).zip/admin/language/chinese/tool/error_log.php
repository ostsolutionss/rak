<?php
// Heading
$_['heading_title'] = '错误日志';

// Text
$_['text_success']  = '成功：您已成功清除错误日志！';
$_['text_list']        = '错误清单';

// Error
$_['error_warning']	   = '警告：您的错误日志文件 %s 是 %s！';
$_['error_permission'] = '警告：您没有权限来清除错误日志！';