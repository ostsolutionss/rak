<?php
// Heading
$_['heading_title']					= '退款交易';

// Text
$_['text_pp_express']				= 'PayPal快速结帐';
$_['text_current_refunds']			= '这项交易的退款已经完成了。最大退款额为';

// Entry
$_['entry_transaction_id']			= '交易 ID';
$_['entry_full_refund']				= '全额退款';
$_['entry_amount']					= '金额';
$_['entry_message']					= '信息';

// Button
$_['button_refund']					= '退款问题';

// Error
$_['error_partial_amt']				= '您必须输入部分退款金额';
$_['error_data']					= '请求数据丢失';